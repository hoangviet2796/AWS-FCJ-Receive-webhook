import crypto from "crypto";

const createHmac = (message, algorithm) => {
  const secretKey = process.env.JIRA_SECRET_KEY;
  const hmac = crypto.createHmac(algorithm, secretKey);
  hmac.update(message);
  return hmac.digest("hex");
};

const verifyHmac = (hmacFromMessage, receivedHmac) => {
  return crypto.timingSafeEqual(
    Buffer.from(hmacFromMessage, "utf8"),
    Buffer.from(receivedHmac, "utf8")
  );
};

export const validateHmac = function (payload, signatureString) {
  const parts = signatureString.split("=");

  // The parts array now contains two elements
  const algorithm = parts[0]; // "sha256"
  const signature = parts[1]; // "example_signature"

  try {
    //body = JSON.stringify(payload);
    const hmacFromMessage = createHmac(payload, algorithm);
    if (verifyHmac(hmacFromMessage, signature)) {
      console.log("Invalid HMAC. Dropping webhook");
      return true;
    } else {
      console.log("valid HMAC");
      return false;
    }
  } catch (error) {
    console.log("Error verifying HMAC. Dropping webhook", error);
    return false;
  }
};
