import {DiscordSend} from "./DiscordHandler.mjs"

export const DataHandler = async (payload) => {
  const data = JSON.parse(payload);
  console.log(data.webhookEvent);
  let eventType = data.webhookEvent;
  let taskInfomation = {
    noti: "",
    key: "",
    summary: "",
    description: "",
    changelog: [],
    link: "",
  };
  switch (eventType) {
    case "jira:issue_created":
      taskInfomation.noti = `New task have been created by \`${data.user.displayName}\``;
      taskInfomation.key = data.issue.key;
      taskInfomation.summary = data.issue.fields.summary;
      taskInfomation.description = data.issue.fields.description.substr(0,150) + "...";
      taskInfomation.changelog = data.changelog.items.map((item) => {
        let valueStr;
        if(item.toString.length >= 150)
          valueStr = item.toString.substr(0,150) + "...";
        else
          valueStr = item.toString
        return {
          name: item.field,
          value: valueStr,
          inline: true
        };
      });
      break;
    case "jira:issue_updated":
      taskInfomation.noti = `Task ${data.issue.key} have been updated by \`${data.user.displayName}]\``;
      taskInfomation.key = data.issue.key;
      taskInfomation.summary = data.issue.fields.summary;
      taskInfomation.description = data.issue.fields.description.substr(0,150) + "...";
      taskInfomation.changelog = data.changelog.items.map((item) => {
        return {
          name: item.field,
          value: `from:${item.fromString} -> to: ${item.toString}`,
        };
      });
      break;
    default:
      break;
  }
  
  await DiscordSend(taskInfomation);
    
}