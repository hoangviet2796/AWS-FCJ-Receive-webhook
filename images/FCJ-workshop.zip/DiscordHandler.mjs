import { EmbedBuilder, WebhookClient } from "discord.js";

export const DiscordSend = async (taskInfomation) => {
  const webhookClient = new WebhookClient({
    id: process.env.DISCORD_ID,
    token: process.env.DISCORD_TOKEN,
  });

  const embed = new EmbedBuilder()
    .setTitle(`[${taskInfomation.key}]- ${taskInfomation.summary}`)
    .setDescription(taskInfomation.description)
    .setColor(0x00ffff)
    .addFields(
      taskInfomation.changelog.filter((item) => {
        return item.name != "description" && item.name != "summary";
      })
    )
    .setTimestamp();

  await webhookClient.send({
    content: taskInfomation.noti,
    username: "JIRA Helper",
    avatarURL: "https://imgur.com/mDl1cJF.png",
    embeds: [embed],
  });
  console.log(JSON.stringify(taskInfomation, null, 2));
};
