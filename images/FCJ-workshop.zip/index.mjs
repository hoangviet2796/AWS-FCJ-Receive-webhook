import  {DataHandler} from "./DataHandler.mjs"
import {validateHmac} from "./validateHmac.mjs"

export const handler = async (event) => {
  
  for (const record of event.Records) {
    console.log("message attributes ", record.messageAttributes);

    const payload = record.body;
    const hmacSignature = record.messageAttributes.signature.stringValue;

    try {
      if (validateHmac(payload, hmacSignature)) {
        await DataHandler(payload);
      }
      else 
        continue;
    } catch (error) {
      console.log("Error", error);
      continue;
    }

  }
};
